import { useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  Check,
  ChefHat,
  ChevronDown,
  Clock3,
  ExternalLink,
  Facebook,
  Instagram,
  MapPin,
  Menu,
  Phone,
  Quote,
  Send,
  ShieldCheck,
  Sparkles,
  Star,
  Utensils,
  Users,
  X,
} from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const directionsUrl = 'https://maps.app.goo.gl/mUaiMz7Mdhj3ZSUp8';
const phoneNumber = '8828384962';
const businessAddress =
  'D-Mart, Y K, Chintamani Vihar, Tirupati Nagar Phase II, Y K Nagar, Virar West, Vasai-Virar, Maharashtra 401303';

const services = [
  { title: 'Wedding Catering', text: 'Thoughtful menus and graceful service for the day you have been imagining.', icon: Sparkles },
  { title: 'Birthday Parties', text: 'Joyful, easy-to-love food that lets the host enjoy every moment too.', icon: Star },
  { title: 'Corporate Events', text: 'Well-presented meals for teams, launches, meetings and everything in between.', icon: Users },
  { title: 'Family Functions', text: 'Comforting favourites and familiar flavours, prepared with a little extra care.', icon: Utensils },
  { title: 'Special Occasions', text: 'Make milestones feel personal with food that becomes part of the memory.', icon: ChefHat },
  { title: 'Custom Catering', text: 'Tell us the occasion, the people and your preferences. We will shape the menu around it.', icon: ShieldCheck },
];

const benefits = [
  { title: 'Fresh & Delicious Food', icon: ChefHat },
  { title: 'Hygienic Preparation', icon: ShieldCheck },
  { title: 'Professional Service', icon: Sparkles },
  { title: 'Customizable Menus', icon: Utensils },
  { title: 'Suitable for Small & Large Events', icon: Users },
  { title: 'On-Time Service', icon: Clock3 },
];

const gallery = [
  { src: '/gallery-thali.png', alt: 'Colourful Indian thali arranged for a celebration', label: 'The first bite' },
  { src: '/gallery-buffet.png', alt: 'Elegant Indian buffet dishes ready to be served', label: 'A generous spread' },
  { src: '/gallery-dessert.png', alt: 'Indian desserts arranged on ceramic serving plates', label: 'A sweet finish' },
];

const sampleTestimonials = [
  { quote: 'Sample testimonial — replace this with a real customer review after your next event.', name: 'Sample customer', detail: 'Placeholder review' },
  { quote: 'Sample testimonial — replace this with a real customer review after your next event.', name: 'Sample customer', detail: 'Placeholder review' },
  { quote: 'Sample testimonial — replace this with a real customer review after your next event.', name: 'Sample customer', detail: 'Placeholder review' },
];

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.12 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  return ref;
}

function Reveal({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const ref = useReveal();
  return <div ref={ref} className={`reveal ${className}`}>{children}</div>;
}

function BrandMark({ inverse = false }: { inverse?: boolean }) {
  return (
    <a href="#home" className="focus-ring flex items-center gap-3" data-testid="link-brand">
      <span className={`grid h-11 w-11 place-items-center rounded-full border ${inverse ? 'border-accent/60 bg-accent text-foreground' : 'border-primary/25 bg-primary text-primary-foreground'}`}>
        <span className="font-display text-xl font-bold leading-none">J</span>
      </span>
      <span className="leading-none">
        <span className={`block font-mono-brand text-[10px] font-bold uppercase tracking-[.24em] ${inverse ? 'text-accent' : 'text-primary'}`}>Jayshree</span>
        <span className={`mt-1 block font-display text-lg font-bold tracking-tight ${inverse ? 'text-card' : 'text-foreground'}`}>Caterers</span>
      </span>
    </a>
  );
}

function NavLink({ href, children, onClick }: { href: string; children: React.ReactNode; onClick?: () => void }) {
  return <a href={href} onClick={onClick} className="focus-ring rounded-full px-3 py-2 text-sm font-semibold text-foreground/75 transition-colors hover:bg-primary/10 hover:text-primary" data-testid={`link-nav-${href.replace('#', '')}`}>{children}</a>;
}

function Navigation() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b border-border/70 bg-background/90 backdrop-blur-xl">
      <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-12">
        <BrandMark />
        <nav className="hidden items-center gap-1 md:flex" aria-label="Main navigation">
          <NavLink href="#about">Our story</NavLink>
          <NavLink href="#services">Services</NavLink>
          <NavLink href="#gallery">Gallery</NavLink>
          <NavLink href="#contact">Contact</NavLink>
        </nav>
        <div className="hidden items-center gap-4 md:flex">
          <a href={`tel:${phoneNumber}`} className="focus-ring flex items-center gap-2 text-sm font-bold text-primary" data-testid="link-nav-phone">
            <Phone className="h-4 w-4" strokeWidth={2.5} /> {phoneNumber}
          </a>
          <a href="#enquire" className="focus-ring rounded-full bg-primary px-5 py-3 text-sm font-bold text-primary-foreground shadow-sm transition-transform hover:-translate-y-0.5" data-testid="link-nav-enquire">Plan your menu <ArrowRight className="ml-1 inline h-4 w-4" /></a>
        </div>
        <button type="button" aria-expanded={open} aria-controls="mobile-navigation" onClick={() => setOpen(!open)} className="focus-ring rounded-full border border-border p-2.5 md:hidden" data-testid="button-toggle-navigation">
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          <span className="sr-only">{open ? 'Close menu' : 'Open menu'}</span>
        </button>
      </div>
      {open && (
        <nav id="mobile-navigation" className="border-t border-border bg-card px-5 py-4 md:hidden" aria-label="Mobile navigation">
          <div className="flex flex-col gap-1">
            <NavLink href="#about" onClick={close}>Our story</NavLink>
            <NavLink href="#services" onClick={close}>Services</NavLink>
            <NavLink href="#gallery" onClick={close}>Gallery</NavLink>
            <NavLink href="#contact" onClick={close}>Contact</NavLink>
            <a href="#enquire" onClick={close} className="mt-3 rounded-full bg-primary px-4 py-3 text-center text-sm font-bold text-primary-foreground" data-testid="link-mobile-enquire">Plan your menu <ArrowRight className="ml-1 inline h-4 w-4" /></a>
          </div>
        </nav>
      )}
    </header>
  );
}

function Hero() {
  return (
    <section id="home" className="relative isolate flex min-h-[720px] items-end overflow-hidden bg-secondary pt-24 text-card sm:min-h-[760px] lg:min-h-[810px]">
      <img src="/hero-feast.png" alt="A warm, abundant Indian banquet table" className="absolute inset-0 -z-20 h-full w-full object-cover object-center" />
      <div className="hero-wash absolute inset-0 -z-10" />
      <div className="absolute right-[9%] top-[22%] hidden h-44 w-44 rounded-full border border-accent/30 lg:block" />
      <div className="absolute right-[11%] top-[27%] hidden h-32 w-32 rounded-full border border-accent/20 lg:block" />
      <div className="mx-auto w-full max-w-7xl px-5 pb-16 sm:px-8 sm:pb-24 lg:px-12 lg:pb-28">
        <div className="max-w-3xl">
          <Reveal className="reveal-delay-1">
            <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-accent/45 bg-secondary/40 px-4 py-2 font-mono-brand text-[10px] font-bold uppercase tracking-[.18em] text-accent backdrop-blur-sm" data-testid="badge-trusted-service">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" /> Trusted Catering Services in Virar
            </div>
          </Reveal>
          <Reveal className="reveal-delay-2">
            <h1 className="text-balance font-display text-5xl font-semibold leading-[.98] tracking-[-.04em] text-card sm:text-7xl lg:text-[6.8rem]">Delicious Food.<br /><span className="text-accent">Memorable Events.</span></h1>
          </Reveal>
          <Reveal className="reveal-delay-3">
            <p className="mt-7 max-w-xl text-base leading-7 text-card/80 sm:text-lg">From the first menu conversation to the final plate, Jayshree Caterers brings generous food, warm hospitality and a considered touch to your celebration.</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
              <a href={`tel:${phoneNumber}`} className="focus-ring inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-bold text-primary-foreground transition-transform hover:-translate-y-1" data-testid="link-hero-call"><Phone className="h-4 w-4" /> Call Now</a>
              <a href={directionsUrl} target="_blank" rel="noreferrer" className="focus-ring inline-flex items-center justify-center gap-2 rounded-full border border-card/40 bg-card/10 px-6 py-3.5 text-sm font-bold text-card backdrop-blur-sm transition-colors hover:bg-card hover:text-secondary" data-testid="link-hero-directions"><MapPin className="h-4 w-4" /> Get Directions <ExternalLink className="h-3.5 w-3.5 opacity-60" /></a>
            </div>
          </Reveal>
        </div>
        <div className="mt-20 flex items-end justify-between border-t border-card/20 pt-5 text-xs text-card/60 sm:mt-28">
          <span className="font-mono-brand uppercase tracking-[.14em]">Virar · Vasai-Virar · nearby areas</span>
          <a href="#about" className="hidden items-center gap-2 font-semibold text-card transition-colors hover:text-accent sm:flex" data-testid="link-hero-scroll">Discover our approach <ChevronDown className="h-4 w-4" /></a>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="bg-background px-5 py-24 sm:px-8 lg:px-12 lg:py-36">
      <div className="mx-auto grid max-w-7xl gap-16 lg:grid-cols-[.8fr_1.2fr] lg:items-start lg:gap-28">
        <Reveal>
          <p className="font-mono-brand text-[11px] font-bold uppercase tracking-[.2em] text-primary">01 / Our approach</p>
          <h2 className="mt-5 max-w-md font-display text-4xl font-semibold leading-[1.05] tracking-[-.03em] sm:text-6xl">Food that makes room for people.</h2>
        </Reveal>
        <Reveal className="reveal-delay-1">
          <p className="max-w-2xl text-xl leading-8 text-foreground/80 sm:text-2xl sm:leading-9">A good event is remembered in details: the first aroma from the kitchen, a plate that looks as good as it tastes, and a host who is free to be present.</p>
          <p className="mt-7 max-w-xl leading-7 text-muted-foreground">Jayshree Caterers is here to make those details easier. We focus on quality food, hygienic preparation, thoughtful presentation and reliable service for celebrations across Virar, Vasai-Virar and nearby areas.</p>
          <div className="mt-10 grid max-w-xl grid-cols-2 gap-6 border-t border-border pt-7 sm:grid-cols-4">
            {['Quality first', 'Hygiene always', 'Beautifully served', 'Dependable care'].map((item, index) => (
              <div key={item} data-testid={`text-approach-${index}`}><Check className="mb-3 h-4 w-4 text-primary" /><p className="text-sm font-bold leading-5">{item}</p></div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="bg-secondary px-5 py-24 text-card sm:px-8 lg:px-12 lg:py-32">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
            <div><p className="font-mono-brand text-[11px] font-bold uppercase tracking-[.2em] text-accent">02 / For every kind of gathering</p><h2 className="mt-5 max-w-2xl font-display text-4xl font-semibold leading-[1.05] tracking-[-.03em] sm:text-6xl">The menu starts with your moment.</h2></div>
            <p className="max-w-xs text-sm leading-6 text-card/60">One conversation is enough to begin. We will listen, suggest and shape the food around your occasion.</p>
          </div>
        </Reveal>
        <div className="mt-16 grid border-l border-t border-card/15 sm:grid-cols-2 lg:grid-cols-3">
          {services.map(({ title, text, icon: Icon }, index) => (
            <Reveal key={title} className={`border-b border-r border-card/15 ${index % 2 ? 'reveal-delay-1' : ''}`}>
              <article className="group min-h-[250px] p-7 transition-colors hover:bg-card/10 sm:p-9">
                <div className="flex items-start justify-between"><Icon className="h-7 w-7 text-accent" strokeWidth={1.5} /><span className="font-mono-brand text-[10px] text-card/35">0{index + 1}</span></div>
                <h3 className="mt-16 font-display text-2xl font-semibold">{title}</h3>
                <p className="mt-3 max-w-xs text-sm leading-6 text-card/60">{text}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Benefits() {
  return (
    <section className="bg-accent px-5 py-20 sm:px-8 lg:px-12 lg:py-24">
      <div className="mx-auto flex max-w-7xl flex-col gap-12 lg:flex-row lg:items-center lg:justify-between">
        <Reveal><div><p className="font-mono-brand text-[11px] font-bold uppercase tracking-[.2em] text-foreground/60">03 / The Jayshree standard</p><h2 className="mt-5 max-w-sm font-display text-4xl font-semibold leading-[1.05] tracking-[-.03em] sm:text-5xl">The details guests notice.</h2></div></Reveal>
        <div className="grid flex-1 gap-x-10 gap-y-7 sm:grid-cols-2 lg:max-w-2xl">
          {benefits.map(({ title, icon: Icon }, index) => (
            <Reveal key={title} className={index % 2 ? 'reveal-delay-1' : ''}><div className="flex items-center gap-4 border-b border-foreground/15 pb-4" data-testid={`benefit-${index}`}><Icon className="h-5 w-5 shrink-0 text-primary" strokeWidth={1.8} /><span className="text-sm font-bold">{title}</span></div></Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Gallery() {
  return (
    <section id="gallery" className="bg-background px-5 py-24 sm:px-8 lg:px-12 lg:py-36">
      <div className="mx-auto max-w-7xl">
        <Reveal><div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><p className="font-mono-brand text-[11px] font-bold uppercase tracking-[.2em] text-primary">04 / From our kitchen</p><h2 className="mt-5 font-display text-4xl font-semibold tracking-[-.03em] sm:text-6xl">A table worth gathering around.</h2></div><p className="max-w-xs text-sm leading-6 text-muted-foreground">Colour, comfort and a little theatre — because presentation is part of the welcome.</p></div></Reveal>
        <div className="mt-14 grid gap-5 md:grid-cols-[1.1fr_.9fr]">
          <Reveal className="h-full">
            <figure className="group relative h-full min-h-[440px] overflow-hidden rounded-[2rem] bg-muted">
              <img src={gallery[0].src} alt={gallery[0].alt} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" data-testid="img-gallery-thali" />
              <figcaption className="absolute inset-x-5 bottom-5 flex items-center justify-between rounded-full bg-secondary/85 px-5 py-3 text-sm font-bold text-card backdrop-blur-md"><span>{gallery[0].label}</span><span className="font-mono-brand text-[10px] text-accent">01</span></figcaption>
            </figure>
          </Reveal>
          <div className="grid gap-5 sm:grid-cols-2 md:grid-cols-1">
            {gallery.slice(1).map((item, index) => (
              <Reveal key={item.src} className={index === 1 ? 'reveal-delay-1' : ''}><figure className="group relative h-[300px] overflow-hidden rounded-[2rem] bg-muted sm:h-full md:h-[300px]"><img src={item.src} alt={item.alt} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" data-testid={`img-gallery-${index + 2}`} /><figcaption className="absolute inset-x-5 bottom-5 flex items-center justify-between rounded-full bg-secondary/85 px-5 py-3 text-sm font-bold text-card backdrop-blur-md"><span>{item.label}</span><span className="font-mono-brand text-[10px] text-accent">0{index + 2}</span></figcaption></figure></Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="bg-card px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
      <div className="mx-auto max-w-7xl">
        <Reveal><div className="max-w-xl"><p className="font-mono-brand text-[11px] font-bold uppercase tracking-[.2em] text-primary">05 / In their words</p><h2 className="mt-5 font-display text-4xl font-semibold leading-[1.05] tracking-[-.03em] sm:text-6xl">The good kind of full.</h2><p className="mt-5 text-sm leading-6 text-muted-foreground">Sample placeholder testimonials — replace these with real customer reviews. These are not Google reviews.</p></div></Reveal>
        <div className="mt-14 grid gap-5 lg:grid-cols-3">
          {sampleTestimonials.map((item, index) => (
            <Reveal key={`${item.name}-${index}`} className={index === 1 ? 'reveal-delay-1' : index === 2 ? 'reveal-delay-2' : ''}><article className="flex min-h-[280px] flex-col justify-between rounded-[1.5rem] border border-border bg-background p-7" data-testid={`card-sample-testimonial-${index}`}><div><Quote className="h-8 w-8 text-primary/40" /><p className="mt-7 font-display text-xl leading-7">{item.quote}</p></div><div className="mt-8 flex items-center justify-between border-t border-border pt-5"><div><p className="text-sm font-bold">{item.name}</p><p className="mt-1 font-mono-brand text-[9px] uppercase tracking-[.13em] text-muted-foreground">{item.detail}</p></div><div className="flex gap-1 text-accent" aria-label="Sample rating"><Star className="h-3.5 w-3.5 fill-current" /><Star className="h-3.5 w-3.5 fill-current" /><Star className="h-3.5 w-3.5 fill-current" /></div></div></article></Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

type FormState = { name: string; phone: string; eventType: string; eventDate: string; guests: string; message: string };
const emptyForm: FormState = { name: '', phone: '', eventType: '', eventDate: '', guests: '', message: '' };

function EnquiryForm() {
  const [form, setForm] = useState<FormState>(emptyForm);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [sent, setSent] = useState(false);
  const update = (field: keyof FormState) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
    setErrors((current) => ({ ...current, [field]: '' }));
  };
  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const next: Partial<Record<keyof FormState, string>> = {};
    if (!form.name.trim()) next.name = 'Please add your name.';
    if (!/^[0-9+\s()-]{8,}$/.test(form.phone.trim())) next.phone = 'Please add a valid phone number.';
    if (!form.eventType) next.eventType = 'Please choose an event type.';
    if (!form.eventDate) next.eventDate = 'Please choose an event date.';
    if (!form.guests || Number(form.guests) < 1) next.guests = 'Please add the number of guests.';
    if (!form.message.trim()) next.message = 'Tell us a little about your occasion.';
    if (Object.keys(next).length) { setErrors(next); setSent(false); return; }
    setSent(true);
    setForm(emptyForm);
    setErrors({});
  };
  if (sent) {
    return <div className="rounded-[1.5rem] border border-accent/40 bg-accent/15 p-8 sm:p-10" role="status" data-testid="status-enquiry-success"><div className="grid h-12 w-12 place-items-center rounded-full bg-primary text-primary-foreground"><Check className="h-6 w-6" /></div><h3 className="mt-7 font-display text-3xl font-semibold">Your enquiry is on its way.</h3><p className="mt-3 max-w-md leading-7 text-muted-foreground">Thank you for sharing the details. This form is ready to connect to a backend or email service. For now, call us directly at <a className="font-bold text-primary underline underline-offset-4" href={`tel:${phoneNumber}`} data-testid="link-success-phone">{phoneNumber}</a> to continue the conversation.</p><button type="button" onClick={() => setSent(false)} className="focus-ring mt-7 rounded-full border border-primary px-5 py-3 text-sm font-bold text-primary transition-colors hover:bg-primary hover:text-primary-foreground" data-testid="button-send-another-enquiry">Send another enquiry</button></div>;
  }
  const inputClass = (field: keyof FormState) => `mt-2 w-full rounded-xl border bg-background px-4 py-3.5 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/15 ${errors[field] ? 'border-destructive' : 'border-border'}`;
  return (
    <form onSubmit={submit} noValidate className="grid gap-5" data-testid="form-enquiry">
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="text-sm font-bold">Name <span className="text-primary">*</span><input type="text" value={form.name} onChange={update('name')} className={inputClass('name')} placeholder="Your name" data-testid="input-name" aria-invalid={Boolean(errors.name)} />{errors.name && <span className="mt-1 block text-xs font-medium text-destructive">{errors.name}</span>}</label>
        <label className="text-sm font-bold">Phone Number <span className="text-primary">*</span><input type="tel" value={form.phone} onChange={update('phone')} className={inputClass('phone')} placeholder="Your phone number" data-testid="input-phone" aria-invalid={Boolean(errors.phone)} />{errors.phone && <span className="mt-1 block text-xs font-medium text-destructive">{errors.phone}</span>}</label>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="text-sm font-bold">Event Type <span className="text-primary">*</span><select value={form.eventType} onChange={update('eventType')} className={inputClass('eventType')} data-testid="select-event-type" aria-invalid={Boolean(errors.eventType)}><option value="">Choose an event</option>{services.map((service) => <option key={service.title} value={service.title}>{service.title}</option>)}</select>{errors.eventType && <span className="mt-1 block text-xs font-medium text-destructive">{errors.eventType}</span>}</label>
        <label className="text-sm font-bold">Event Date <span className="text-primary">*</span><input type="date" value={form.eventDate} onChange={update('eventDate')} className={inputClass('eventDate')} data-testid="input-event-date" aria-invalid={Boolean(errors.eventDate)} />{errors.eventDate && <span className="mt-1 block text-xs font-medium text-destructive">{errors.eventDate}</span>}</label>
      </div>
      <label className="text-sm font-bold">Number of Guests <span className="text-primary">*</span><input type="number" min="1" value={form.guests} onChange={update('guests')} className={inputClass('guests')} placeholder="Approximate guest count" data-testid="input-guests" aria-invalid={Boolean(errors.guests)} />{errors.guests && <span className="mt-1 block text-xs font-medium text-destructive">{errors.guests}</span>}</label>
      <label className="text-sm font-bold">Message <span className="text-primary">*</span><textarea value={form.message} onChange={update('message')} className={`${inputClass('message')} min-h-32 resize-y`} placeholder="Tell us about your occasion, menu preferences or anything else we should know." data-testid="textarea-message" aria-invalid={Boolean(errors.message)} />{errors.message && <span className="mt-1 block text-xs font-medium text-destructive">{errors.message}</span>}</label>
      <button type="submit" className="focus-ring mt-2 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-4 text-sm font-bold text-primary-foreground transition-transform hover:-translate-y-0.5 sm:w-fit" data-testid="button-send-enquiry">Send Enquiry <Send className="h-4 w-4" /></button>
      <p className="text-xs leading-5 text-muted-foreground">Your details will be used to respond to this enquiry. No payment or booking is taken here.</p>
    </form>
  );
}

function Contact() {
  return (
    <section id="contact" className="bg-secondary px-5 py-24 text-card sm:px-8 lg:px-12 lg:py-36">
      <div className="mx-auto grid max-w-7xl gap-16 lg:grid-cols-[.8fr_1.2fr] lg:gap-24">
        <Reveal>
          <p className="font-mono-brand text-[11px] font-bold uppercase tracking-[.2em] text-accent">06 / Let&apos;s talk food</p>
          <h2 className="mt-5 font-display text-5xl font-semibold leading-[1.02] tracking-[-.04em] sm:text-7xl">Your occasion,<br /><span className="text-accent">our table.</span></h2>
          <p className="mt-7 max-w-md leading-7 text-card/65">Share a few details and we will help you take the next step. Prefer to speak now? We are just a call away.</p>
          <div className="mt-10 space-y-5 border-t border-card/15 pt-7">
            <a href={`tel:${phoneNumber}`} className="focus-ring flex items-center gap-4 text-lg font-bold transition-colors hover:text-accent" data-testid="link-contact-phone"><span className="grid h-10 w-10 place-items-center rounded-full bg-card/10"><Phone className="h-4 w-4" /></span>{phoneNumber}</a>
            <div className="flex items-start gap-4 text-sm leading-6 text-card/70"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-card/10"><MapPin className="h-4 w-4" /></span><span>{businessAddress}<br /><span className="text-xs text-card/50">Serving Virar, Vasai-Virar and nearby areas</span></span></div>
            <a href={directionsUrl} target="_blank" rel="noreferrer" className="focus-ring inline-flex items-center gap-2 text-sm font-bold text-accent underline decoration-accent/40 underline-offset-4 hover:decoration-accent" data-testid="link-contact-directions">Open Google Business Profile directions <ExternalLink className="h-3.5 w-3.5" /></a>
          </div>
        </Reveal>
        <Reveal className="reveal-delay-1">
          <div id="enquire" className="rounded-[1.5rem] bg-card p-6 text-foreground sm:p-10"><div className="mb-8 flex items-start justify-between gap-5"><div><h3 className="font-display text-3xl font-semibold">Plan your menu</h3><p className="mt-2 text-sm text-muted-foreground">A few details help us start in the right place.</p></div><span className="font-mono-brand text-[10px] font-bold uppercase tracking-[.15em] text-primary">Enquiry</span></div><EnquiryForm /></div>
          <div className="mt-5 h-48 overflow-hidden rounded-[1.5rem] border border-card/15 bg-card/10 sm:h-56"><iframe title="Map showing Virar, Maharashtra" src="https://www.google.com/maps?q=Virar%2C%20Maharashtra&output=embed" className="h-full w-full border-0 opacity-90 grayscale-[.2]" loading="lazy" referrerPolicy="no-referrer-when-downgrade" data-testid="iframe-location-map" /></div>
        </Reveal>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-secondary px-5 pb-8 pt-16 text-card sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-12 border-b border-card/15 pb-14 md:grid-cols-[1.4fr_.7fr_.9fr]">
          <div><BrandMark inverse /><p className="mt-6 max-w-xs text-sm leading-6 text-card/55">Quality food, warmly served — for moments worth gathering around.</p></div>
          <div><p className="font-mono-brand text-[10px] font-bold uppercase tracking-[.18em] text-accent">Explore</p><nav className="mt-5 flex flex-col items-start gap-3 text-sm text-card/65"><a href="#about" className="focus-ring hover:text-accent" data-testid="link-footer-about">Our story</a><a href="#services" className="focus-ring hover:text-accent" data-testid="link-footer-services">Services</a><a href="#gallery" className="focus-ring hover:text-accent" data-testid="link-footer-gallery">Gallery</a><a href="#contact" className="focus-ring hover:text-accent" data-testid="link-footer-contact">Contact</a></nav></div>
            <div><p className="font-mono-brand text-[10px] font-bold uppercase tracking-[.18em] text-accent">Find us</p><p className="mt-5 text-sm leading-6 text-card/65">{businessAddress}<br />Serving Virar, Vasai-Virar<br />and nearby areas</p><a href={directionsUrl} target="_blank" rel="noreferrer" className="focus-ring mt-4 inline-flex items-center gap-2 text-sm font-bold text-accent" data-testid="link-footer-directions">Google Business Profile <ExternalLink className="h-3.5 w-3.5" /></a></div>
        </div>
        <div className="flex flex-col gap-3 pt-7 text-xs text-card/40 sm:flex-row sm:items-center sm:justify-between"><span>© {new Date().getFullYear()} Jayshree Caterers. All rights reserved.</span><a href={`tel:${phoneNumber}`} className="focus-ring flex items-center gap-2 hover:text-accent" data-testid="link-footer-phone"><Phone className="h-3.5 w-3.5" /> {phoneNumber}</a></div>
      </div>
    </footer>
  );
}

function Home() {
  useEffect(() => {
    document.title = 'Jayshree Caterers | Delicious Food. Memorable Events.';
    const description = 'Premium, welcoming catering for weddings, birthdays, corporate events and family functions in Virar, Vasai-Virar and nearby areas.';
    const setMeta = (name: string, content: string, property = false) => {
      const selector = property ? `meta[property="${name}"]` : `meta[name="${name}"]`;
      let tag = document.head.querySelector(selector) as HTMLMetaElement | null;
      if (!tag) { tag = document.createElement('meta'); tag.setAttribute(property ? 'property' : 'name', name); document.head.appendChild(tag); }
      tag.content = content;
    };
    setMeta('description', description);
    setMeta('og:title', 'Jayshree Caterers | Delicious Food. Memorable Events.', true);
    setMeta('og:description', description, true);
    setMeta('og:type', 'website', true);
    setMeta('og:image', '/hero-feast.png', true);
  }, []);
  return <div className="grain min-h-[100dvh]"><Navigation /><main><Hero /><About /><Services /><Benefits /><Gallery /><Testimonials /><Contact /></main><Footer /><a href={`tel:${phoneNumber}`} className="focus-ring fixed bottom-5 right-5 z-30 grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-md transition-transform hover:scale-105 md:hidden" aria-label="Call Jayshree Caterers" data-testid="button-floating-phone"><Phone className="h-5 w-5" /></a></div>;
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;